# Lixus Outreach Builder (Vercel)

Aplikasi statis (`index.html`) + satu API (`api/prospects.js`) untuk daftar prospek bersama.
Tanpa langkah 3-5 di bawah, aplikasi tetap jalan dalam **mode lokal** (data hanya di browser masing-masing).

## Deploy
1. Upload folder ini ke GitHub, lalu di vercel.com pilih **Add New > Project** dan import repo-nya
   (atau jalankan `npx vercel` di folder ini). Framework preset: **Other**.
2. Deploy. Aplikasi sudah bisa dipakai dalam mode lokal.

## Aktifkan daftar prospek bersama
3. Di project Vercel: **Storage > Create / Connect** database **Upstash Redis** (Marketplace).
   Variabel `KV_REST_API_URL` dan `KV_REST_API_TOKEN` otomatis ditambahkan.
4. Di **Settings > Environment Variables**, tambahkan `TEAM_PASSWORD` dengan password pilihan Anda.
5. **Redeploy** project.

## Dipakai tim
Buka URL project, isi **Nama Anda (PIC)** dan **Team password**, klik **Hubungkan daftar bersama**.
Daftar diperbarui otomatis tiap 20 detik.

## Catatan keamanan
- Siapa pun yang tahu URL dan team password bisa membaca, mengubah, dan menghapus semua prospek.
- Password dikirim lewat HTTPS, tetapi hanya satu password bersama (belum ada login per orang).
- Isi data berupa nama prospek, trigger, dan link riset. Jangan masukkan data sensitif lain.
