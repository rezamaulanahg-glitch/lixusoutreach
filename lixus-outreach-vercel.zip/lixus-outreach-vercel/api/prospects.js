// Vercel Serverless Function: shared prospect list stored in Upstash Redis (Vercel Marketplace).
const URL_ = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
const HASH = "lixus:prospects";

async function redis(cmd) {
  const r = await fetch(URL_, {
    method: "POST",
    headers: { Authorization: `Bearer ${TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify(cmd),
  });
  const j = await r.json();
  if (!r.ok || j.error) throw new Error(j.error || String(r.status));
  return j.result;
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (!process.env.TEAM_PASSWORD || !URL_ || !TOKEN) {
    return res.status(500).json({ error: "Server belum dikonfigurasi (TEAM_PASSWORD / Redis)." });
  }
  if (req.headers["x-team-key"] !== process.env.TEAM_PASSWORD) {
    return res.status(401).json({ error: "unauthorized" });
  }
  try {
    if (req.method === "GET") {
      const flat = (await redis(["HGETALL", HASH])) || [];
      const out = [];
      for (let i = 0; i < flat.length; i += 2) {
        try { out.push({ ...JSON.parse(flat[i + 1]), docId: flat[i] }); } catch (e) {}
      }
      return res.status(200).json(out);
    }
    if (req.method === "PUT") {
      const b = typeof req.body === "string" ? JSON.parse(req.body) : req.body || {};
      const { id, data } = b;
      if (!id || typeof id !== "string" || id.length > 200 || !data || typeof data !== "object") {
        return res.status(400).json({ error: "bad request" });
      }
      const body = JSON.stringify(data);
      if (body.length > 50000) return res.status(413).json({ error: "too large" });
      await redis(["HSET", HASH, id, body]);
      return res.status(200).json({ ok: true });
    }
    if (req.method === "DELETE") {
      const id = req.query && req.query.id;
      if (!id) return res.status(400).json({ error: "bad request" });
      await redis(["HDEL", HASH, String(id)]);
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: "method not allowed" });
  } catch (e) {
    return res.status(500).json({ error: "storage error" });
  }
};
